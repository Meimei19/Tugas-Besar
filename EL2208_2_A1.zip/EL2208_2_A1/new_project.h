#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mode.h"

void new_project();
char*** create_matrix();
void matrix_to_csv(char s[50], char ***A);
