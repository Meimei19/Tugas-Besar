#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void show_display(char ***A);
void schedule_manual (char*** A);
void rule_checker(char ***A);
void assign_manual(char ***B);
void assign_automatic(char ***B);
void schedule_automatic(char ***B);